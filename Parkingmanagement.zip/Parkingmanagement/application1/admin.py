from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(add_category)
admin.site.register(add_vehicle)